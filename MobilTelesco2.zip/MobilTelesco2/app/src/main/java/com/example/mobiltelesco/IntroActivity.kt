package com.example.mobiltelesco
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.mobiltelesco.ui.theme.MobilTelescoTheme

class IntroActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MobilTelescoTheme {
                IntroScreen {
                    startActivity(Intent(this, LoadingActivity::class.java))
                    finish()
                }
            }
        }
    }
}

@Composable
fun IntroScreen(onGetStartedClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Astro Tracking App",
            fontSize = 32.sp,
            color = androidx.compose.ui.graphics.Color.White,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Capture and track celestial wonders.",
            fontSize = 18.sp,
            color = androidx.compose.ui.graphics.Color.LightGray,
            textAlign = TextAlign.Center
        )
        Button(onClick = onGetStartedClick) {
            Text("Get Started")
        }
    }
}