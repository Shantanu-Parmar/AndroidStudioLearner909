
package com.example.mobiltelesco

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.mobiltelesco.ui.theme.MobilTelescoTheme
import androidx.compose.foundation.layout.Column
class CameraActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            // Handle denial (e.g., show toast); for now, log
            Log.e("CameraActivity", "Camera permission denied")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request camera permission if not granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(android.Manifest.permission.CAMERA)
        }

        // Get selected object (for future use, e.g., logging or filtering)
        val selectedObject = intent.getStringExtra("SELECTED_OBJECT") ?: "Unknown"

        setContent {
            MobilTelescoTheme {
                CameraScreen(selectedObject) {
                    finish()  // Back to main
                }
            }
        }
    }
}

@Composable
fun CameraScreen(selectedObject: String, onBackClick: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Sensor states
    var accValues by remember { mutableStateOf("Acc: X=0, Y=0, Z=0") }
    var gyroValues by remember { mutableStateOf("Gyro: X=0, Y=0, Z=0") }
    var magValues by remember { mutableStateOf("Mag: X=0, Y=0, Z=0") }

    // Setup sensors
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    val sensorListener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    val x = it.values[0]
                    val y = it.values[1]
                    val z = it.values[2]
                    when (it.sensor.type) {
                        Sensor.TYPE_ACCELEROMETER -> accValues = "Acc: X=%.2f, Y=%.2f, Z=%.2f".format(x, y, z)
                        Sensor.TYPE_GYROSCOPE -> gyroValues = "Gyro: X=%.2f, Y=%.2f, Z=%.2f".format(x, y, z)
                        Sensor.TYPE_MAGNETIC_FIELD -> magValues = "Mag: X=%.2f, Y=%.2f, Z=%.2f".format(x, y, z)
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
    }

    // Register sensors on compose enter, unregister on exit
    DisposableEffect(Unit) {
        sensorManager.registerListener(sensorListener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(sensorListener, gyroscope, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(sensorListener, magnetometer, SensorManager.SENSOR_DELAY_NORMAL)
        onDispose {
            sensorManager.unregisterListener(sensorListener)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Camera Preview

        AndroidView(
            factory = { viewContext: Context -> // Specify Context type, e.g., viewContext
                val previewView = PreviewView(viewContext).apply { // Use viewContext here
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                val cameraProviderFuture = ProcessCameraProvider.getInstance(viewContext) // Use viewContext

                cameraProviderFuture.addListener(
                    Runnable {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview
                            )
                        } catch (exc: Exception) {
                            Log.e("CameraScreen", "Use case binding failed", exc)
                        }
                    },
                    ContextCompat.getMainExecutor(viewContext) // Use viewContext
                )
                previewView // Return the PreviewView instance
            },
            modifier = Modifier.fillMaxSize()
        )

        // Sensor Overlay (Top-Right)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = accValues,
                fontSize = 14.sp,
                color = androidx.compose.ui.graphics.Color.White,
                textAlign = TextAlign.End
            )
            Text(
                text = gyroValues,
                fontSize = 14.sp,
                color = androidx.compose.ui.graphics.Color.White,
                textAlign = TextAlign.End
            )
            Text(
                text = magValues,
                fontSize = 14.sp,
                color = androidx.compose.ui.graphics.Color.White,
                textAlign = TextAlign.End
            )
        }

        // Back Button (Top-Left)
        Button(
            onClick = onBackClick,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
        ) {
            Text("Back")
        }

        // Optional: Display selected object (Bottom-Center)
        Text(
            text = "Tracking: $selectedObject",
            fontSize = 16.sp,
            color = androidx.compose.ui.graphics.Color.White,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}